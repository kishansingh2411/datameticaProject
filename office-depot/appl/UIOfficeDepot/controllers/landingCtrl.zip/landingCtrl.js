
app.controller('landingPageController', function($scope,$sce,$http,$rootScope,$q,$location,countryService,visitorService, periodService)
{

       // $scope.TR_CYCW = "-";
       // $scope.TD_CYCW = "-";
       // $scope.CA_CYCW = "-";
       // $scope.TV_CYCW = "-";
       // get selected country      
       <!--  
       $scope.foryear = new Date();
       $scope.backyear = new Date()-1;


 


        $scope.countries = [{name: 'UNITED KINGDOM', id: 1 },{name: 'AUSTRIA', id: 2 },{ name: 'BELGIUM', id: 3},{name: 'CZECH REPUBLIC',id: 4 },{name: 'ITALY',id: 5 },{ name: 'NETHERLANDS',id: 6},{ name: 'POLAND', id: 7 },{name: 'IRELAND', id: 8},{name: 'SLOVENIA',id: 9 },{name: 'GERMANY',id: 10 },{name: 'VIKING FRANCE', id:11}];
        
        $scope.visitors = [{
          name: 'All VISITORS',
          id: 1 // note the property casing here
        },{
          name: 'NEW VISITORS',
          id: 2
        },        {
          name: 'EXISTING VISITORS',
          id: 3
        }];

        

        //$scope.content = "Prior Week";

        $scope.sel_country = countryService.get();
        $scope.set = function(country) {
          countryService.set(country);
        };

        //$scope.euro = $sce.trustAsHtml('€');
        //$scope.pound_sign = "£";

        $scope.sel_visitor = visitorService.get();
        $scope.setV = function(visitor) {
          visitorService.set(visitor);
        };

        $scope.setP = function(content){
          console.log("hi");
          periodService.set(content); 
        };
        $scope.content = periodService.get();
        

        var toWk = $.getCurrentWeek(); // actually last week
        var prevWk = $.getWeek(2); //last week
        var prev6Wk = $.getWeek(7); // last 6 week
        var prev13Wk = $.getWeek(14); // last 13 weeks
        var toWeek = services.toWeek + toWk;    // this is imporrtant *******************

        var toWk_Ly = $.getCurrentWeek_Ly(); // actually last week
        var prevWk_Ly = $.getWeek_Ly(2); //last week
        var prev6Wk_Ly = $.getWeek_Ly(7); // last 6 week
        var prev13Wk_Ly = $.getWeek_Ly(14); // last 13 weeks
        var toWeek_Ly = services.toWeek + toWk_Ly;  // this is imporrtant ****************
   
       //$scope.countryName = "Countries";
       // for funnel view
       
      // $scope.getListCountry=function(value){ // pravin code
      //   console.log(value)
      //   $.filtered(value);
      // }
        $("#radio-div").change(function(){
          $('.addstring').text("in comparison to");
        });

        
        $("#Visitor, #countries, #radio-div").change(function(){
          $scope.filterall();
        });

        $scope.selected = 'first';   // kpi page
          $scope.myData = [
              
              {name: 'jQuery', count: 0.005},
              
          ];



        // business indicators
        var clickStream_url = services.common1 + services.block1Weekly;

        $scope.filterall = function(){ 
          //$scope.euro = $sce.trustAsHtml('€');
          //$scope. = "€";
          //$scope.pound_sign = "£";
         // $scope.content = "Prior Week";

          $scope.sel_country = countryService.get() || $scope.countries[0];
          $scope.sel_visitor = visitorService.get() || $scope.visitors[0];          
          
          var sel_country = $('#countries').find(":selected").text(); // For dashboard filed changes
          var sel_visitor = $('#Visitor').find(":selected").text();  

          // {name: 'IRELAND', id: 8},{name: 'SLOVENIA',id: 9 },{name: 'GERMANY',id: 10 },{name: 'VIKING FRANCE', id:11}];
       
          //  $('#countries').change(function(){
          //   var selectdata= $(this).find("option:selected").text();
          //     alert(selectdata);            
          // }).change();

      

          $scope.symb = $sce.trustAsHtml('£');
          if (sel_country ==  "AUSTRIA" || sel_country ==  "BELGIUM" || sel_country ==  "CZECH REPUBLIC" || sel_country ==  "ITALY" || sel_country ==  "NETHERLANDS" || sel_country ==  "POLAND" || sel_country ==  "IRELAND" || sel_country ==  "SLOVENIA" || sel_country ==  "GERMANY" || sel_country ==  "VIKING FRANCE" ){
            $scope.symb = $sce.trustAsHtml('€');
          };
          
          
          //$scope.sel_country = "UNITED KINGDOM";
          // $scope.symb = $sce.trustAsHtml('€');
          // if(sel_country == "UNITED KINGDOM"){
          //     $scope.symb = $sce.trustAsHtml('£');
          // };
          // else $scope.symb = $sce.trustAsHtml('€');

          console.log($scope.sel_country);

          // var euro = $sce.trustAsHtml('€');
          // var pound = $sce.trustAsHtml('£');



          // else {
          //   console.log("other");$scope.symb = $sce.trustAsHtml('€');
          // }
          //var sel_period = $scope.content;

          // $scope.scopeCoun = sel_country;
          // $scope.scopevisit = sel_visitor;

          //$scope.content = "Last Week"  // default selection
          //console.log(sel_period);


          var fromWeek = services.fromWeek + toWk;   //1
          var fromWeek_Ly = services.fromWeek + toWk_Ly;  //2
          var from1Week = services.fromWeek + prevWk;      //3
          var toLWeek = services.toWeek + prevWk;

          var from1Week_Ly = services.fromWeek + prevWk_Ly;  //4
          var toLWeek_Ly = services.toWeek + prevWk_Ly;

          var from6Week = services.fromWeek + prev6Wk;  //5

          var from6Week_Ly = services.fromWeek + prev6Wk_Ly;      // 6
          var from13Week = services.fromWeek + prev13Wk;         // 7
          var from13Week_Ly = services.fromWeek + prev13Wk_Ly;  //8



          var funnel_url = services.common1 + services.block2nd;
          

             $http.get(funnel_url + fromWeek + toWeek)               //1
              .success(function(response) 
                   {                     

                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView1', "Last Week Current Year", 1);
            
                  });

              $http.get(funnel_url + fromWeek_Ly + toWeek_Ly)   // 2. CWPY  
              .success(function(response) 
                 {      
                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView2', "Last Week Last Year", 1);
                 
                 });



              $http.get(funnel_url + from1Week + toLWeek)           //3
              .success(function(response) 
                  {      
                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView3', "Prior Week Current year", 1);

                  });

              $http.get(funnel_url + from1Week_Ly + toLWeek_Ly)           //4
              .success(function(response) 
                  {      
                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView4', "Prior Week Last year", 1);
                  });




          

 $http.get(funnel_url + from6Week + toWeek)           //5
              .success(function(response) 
                  {      
                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView5', "Prior 6 Week Avg Current Year", 6);

                 });

              $http.get(funnel_url + from6Week_Ly + toWeek_Ly)           //6
              .success(function(response) 
                  {      
                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView6', "Prior 6 Week Avg Last Year", 6);

                 });

              $http.get(funnel_url + from13Week + toWeek)           //7
              .success(function(response) 
                  {      
                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView7', "Prior 13 Week Avg Current Year", 13);

                 });

              $http.get(funnel_url + from13Week_Ly + toWeek_Ly)           //8
              .success(function(response) 
                  {      
                 var graph = $.formatToJSON(response); 
                 var filteredCountries = $.filteredCountry(graph);
                 var filteredSegmentFunnel = $.filtered(filteredCountries); 
                 var funnelDataView = $.getStructuredDataFunnel(filteredSegmentFunnel);
                 $.funneDataChart(funnelDataView, '#funnelView8', "Prior 13 Week Avg Last Year", 13);
                 
                 });


 
               
              var fromWeek = services.fromWeek + toWk;            // 1
              $http.get(clickStream_url + fromWeek + toWeek)
                  .success(function(response) 
                      {
                        var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                        $scope.TR_CYCW = parseInt(mainData.TR);   
                        $scope.TO_CYCW = parseInt(mainData.TO);
                        $scope.CA_CYCW = parseInt(mainData.CA);
                        $scope.TV_CYCW= parseInt(mainData.TV);
                      })
                      .error(function(response){
                        //alert("Last Week not found");
                      });

                    // Last Week prebious year                              //2
              $http.get(clickStream_url + fromWeek_Ly + toWeek_Ly)
                  .success(function(response) 
                      {
                       var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                        
                        $scope.TR_PYCW = parseInt(mainData.TR);   
                        $scope.TO_PYCW = parseInt(mainData.TO);
                        $scope.CA_PYCW = parseInt(mainData.CA);
                        $scope.TV_PYCW= parseInt(mainData.TV);
                      })
                      .error(function(response){
                        //alert("Last Week not found");
                      });

             
              $http.get(clickStream_url + from1Week + toLWeek)                  // 3
                  .success(function(response)   
                      {
                        var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                         
                         $scope.TR_CYPW = parseInt(($scope.TR_CYCW - (mainData.TR) ) / (mainData.TR)*100) ;
                         $scope.TO_CYPW = parseInt(($scope.TO_CYCW - (mainData.TO) ) / (mainData.TO)*100) ;
                         $scope.CA_CYPW = parseInt(($scope.CA_CYCW - (mainData.CA) ) / (mainData.CA)*100) ;
                         $scope.TV_CYPW = parseInt(($scope.TV_CYCW - (mainData.TV) ) / (mainData.TV)*100) ;
                      })
                      .error(function(response){
                        //alert("previous week not found");
                      });

           
            $http.get(clickStream_url + from1Week_Ly + toLWeek_Ly)         //4
                .success(function(response)   
                    {
                      var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                       
                       $scope.TR_PYPW = parseInt(($scope.TR_PYCW - (mainData.TR) ) / (mainData.TR)*100) ;
                       $scope.TO_PYPW = parseInt(($scope.TO_PYCW - (mainData.TO) ) / (mainData.TO)*100) ;
                       $scope.CA_PYPW = parseInt(($scope.CA_PYCW - (mainData.CA) ) / (mainData.CA)*100) ;
                       $scope.TV_PYPW = parseInt(($scope.TV_PYCW - (mainData.TV) ) / (mainData.TV)*100) ;
                    })
                    .error(function(response){
                      //alert("previous week not found");
                    });

                      
              $http.get(clickStream_url + from6Week + toWeek)        //5
                  .success(function(response)   
                      {
                        var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                       

                         
                         $scope.TR_CY6W = parseInt(($scope.TR_CYCW - (mainData.TR / 6) ) / (mainData.TR / 6)*100);
                         $scope.TO_CY6W = parseInt(($scope.TO_CYCW - (mainData.TO / 6) ) / (mainData.TO / 6)*100);
                         $scope.CA_CY6W = parseInt(($scope.CA_CYCW - (mainData.CA / 6) ) / (mainData.CA / 6)*100);
                         $scope.TV_CY6W = parseInt(($scope.TV_CYCW - (mainData.TV / 6) ) / (mainData.TV / 6)*100);
                         //$scope.TO_CY6W = ((mainData.TO) - $scope.TO_CYCW) / $scope.TR_CYCW*100 ;
                         //$scope.CA_CY6W = ((mainData.CA) - $scope.CA_CYCW) / $scope.TR_CYCW*100 ;
                         //$scope.TV_CY6W = ((mainData.TV) - $scope.TV_CYCW) / $scope.TR_CYCW*100 ; 
                         // $scope.TO_CYPW = parseInt(mainData.TO);
                         // $scope.CA_CYPW = parseInt(mainData.CA);
                         // $scope.TV_CYPW= parseInt(mainData.TV);
                      })
                      .error(function(response){
                        //alert("previous week not found");
                      });


              
              $http.get(clickStream_url + from6Week_Ly + toWeek_Ly)          //6
                  .success(function(response)   
                      {
                        var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                         
                         $scope.TR_PY6W = parseInt(($scope.TR_PYCW - (mainData.TR / 6) ) / (mainData.TR / 6)*100);
                         $scope.TO_PY6W = parseInt(($scope.TO_PYCW - (mainData.TO / 6) ) / (mainData.TO / 6)*100);
                         $scope.CA_PY6W = parseInt(($scope.CA_PYCW - (mainData.CA / 6) ) / (mainData.CA / 6)*100);
                         $scope.TV_PY6W = parseInt(($scope.TV_PYCW - (mainData.TV / 6) ) / (mainData.TV / 6)*100);
                         
                      })
                      .error(function(response){
                        //alert("previous week not found");
                      });

              
              $http.get(clickStream_url + from13Week + toWeek)          //7
                  .success(function(response)   
                      {
                        var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                         
                         $scope.TR_CY13W = parseInt(($scope.TR_CYCW - (mainData.TR / 13) ) / (mainData.TR / 13)*100);
                         $scope.TO_CY13W = parseInt(($scope.TO_CYCW - (mainData.TO / 13) ) / (mainData.TO / 13)*100);
                         $scope.CA_CY13W = parseInt(($scope.CA_CYCW - (mainData.CA / 13) ) / (mainData.CA / 13)*100);
                         $scope.TV_CY13W = parseInt(($scope.TV_CYCW - (mainData.TV / 13) ) / (mainData.TV / 13)*100);
                        
                      })
                      .error(function(response){
                        //alert("previous week not found");
                      });

                   
              $http.get(clickStream_url + from13Week_Ly + toWeek_Ly)   //8
                  .success(function(response)   
                      {
                        var header=  $.tableDataDisplay(response);
                        var filteredCountries = $.filteredCountry(header);
                        var returnedData = $.filtered(filteredCountries);
                        var mainData = $.getDatafortable(returnedData);
                         
                         $scope.TR_PY13W = parseInt(($scope.TR_PYCW - (mainData.TR / 13) ) / (mainData.TR / 13)*100);
                         $scope.TO_PY13W = parseInt(($scope.TO_PYCW - (mainData.TO / 13) ) / (mainData.TO / 13)*100);
                         $scope.CA_PY13W = parseInt(($scope.CA_PYCW - (mainData.CA / 13) ) / (mainData.CA / 13)*100);
                         $scope.TV_PY13W = parseInt(($scope.TV_PYCW - (mainData.TV / 13) ) / (mainData.TV / 13)*100);
                        
                      })
                      .error(function(response){
                        //alert("previous week not found");
                      });







                      var kpiurl1 = services.common1 + services.kpi1;  // first KPI
          

                       $http.get(kpiurl1 + fromWeek + toWeek)         //1       
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC1", "OCR", mainData);
                       });
                        $http.get(kpiurl1 + fromWeek_Ly + toWeek_Ly)   //2            
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC2", "OCR", mainData);
                       });

                        $http.get(kpiurl1 + from1Week + toLWeek)                  // 3
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC3", "OCR", mainData);

                            });
                        $http.get(kpiurl1 + from1Week_Ly + toLWeek_Ly)         //4
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC4", "OCR", mainData);

                          });
                        $http.get(kpiurl1 + from6Week + toWeek)        //5
                          .success(function(response)   
                              {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC5", "OCR", mainData);

                          });
                          $http.get(kpiurl1 + from6Week_Ly + toWeek_Ly)          //6
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC6", "OCR", mainData);

                          });
                          $http.get(kpiurl1 + from13Week + toWeek)          //7
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC7", "OCR", mainData);

                          });
                            $http.get(kpiurl1 + from13Week_Ly + toWeek_Ly)   //8
                              .success(function(response)   
                               {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI1(returnedData);

                              $.barChart("#kpi1barC8", "OCR", mainData);

                          });





                       var kpiurl2 = services.common1 + services.kpi2;  // second KPI
          

                       $http.get(kpiurl2 + fromWeek + toWeek)         //1       
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);
                              //console.log(JSON.stringify(returnedData));

                              var mainData = $.getDataforKPI2(returnedData);

                              //console.log(JSON.stringify(mainData));
                              $.barChart("#kpi2barC1", "ARO", mainData);
                       });
                        $http.get(kpiurl2 + fromWeek_Ly + toWeek_Ly)   //2            
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);
                              //console.log(JSON.stringify(returnedData));

                              var mainData = $.getDataforKPI2(returnedData);

                              //console.log(JSON.stringify(mainData));
                              $.barChart("#kpi2barC2", "ARO", mainData);
                       });

                              $http.get(kpiurl2 + from1Week + toLWeek)                  // 3
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI2(returnedData);

                              $.barChart("#kpi2barC3", "ARO", mainData);

                            });
                        $http.get(kpiurl2 + from1Week_Ly + toLWeek_Ly)         //4
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI2(returnedData);

                              $.barChart("#kpi2barC4", "ARO", mainData);

                          });
                        $http.get(kpiurl2 + from6Week + toWeek)        //5
                          .success(function(response)   
                              {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI2(returnedData);

                              $.barChart("#kpi2barC5", "ARO", mainData);

                          });
                          $http.get(kpiurl2 + from6Week_Ly + toWeek_Ly)          //6
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI2(returnedData);

                              $.barChart("#kpi2barC6", "ARO", mainData);

                          });
                          $http.get(kpiurl2 + from13Week + toWeek)          //7
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI2(returnedData);

                              $.barChart("#kpi2barC7", "ARO", mainData);

                          });
                            $http.get(kpiurl2 + from13Week_Ly + toWeek_Ly)   //8
                              .success(function(response)   
                               {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI2(returnedData);

                              $.barChart("#kpi2barC8", "ARO", mainData);

                          });



                      var kpiurl3 = services.common1 + services.kpi3;  // third KPI
          

                       $http.get(kpiurl3 + fromWeek + toWeek)         //1       
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC1", "APVV", mainData);
                       });
                        $http.get(kpiurl3 + fromWeek_Ly + toWeek_Ly)   //2            
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC2", "APPV", mainData);
                       });
                      $http.get(kpiurl3 + from1Week + toLWeek)                  // 3
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC3", "APPV", mainData);

                            });
                        $http.get(kpiurl3 + from1Week_Ly + toLWeek_Ly)         //4
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC4", "APPV", mainData);

                          });
                        $http.get(kpiurl3 + from6Week + toWeek)        //5
                          .success(function(response)   
                              {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC5", "APPV", mainData);

                          });
                          $http.get(kpiurl3 + from6Week_Ly + toWeek_Ly)          //6
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC6", "APPV", mainData);

                          });
                          $http.get(kpiurl3 + from13Week + toWeek)          //7
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC7", "APPV", mainData);

                          });
                            $http.get(kpiurl3 + from13Week_Ly + toWeek_Ly)   //8
                              .success(function(response)   
                               {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI3(returnedData);

                              $.barChart("#kpi3barC8", "APPV", mainData);

                          });



                       var kpiurl4a = services.common1 + services.kpi4a;  // forthA KPI
          

                       $http.get(kpiurl4a + fromWeek + toWeek)         //1       
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC1", "RNC", mainData);
                        });
                        $http.get(kpiurl4a + fromWeek_Ly + toWeek_Ly)   //2            
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC2", "RNC", mainData);
                        });
                        $http.get(kpiurl4a + from1Week + toLWeek)                  // 3
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC3", "RNC", mainData);

                            });
                        $http.get(kpiurl4a + from1Week_Ly + toLWeek_Ly)         //4
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC4", "RNC", mainData);

                          });
                        $http.get(kpiurl4a + from6Week + toWeek)        //5
                          .success(function(response)   
                              {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC5", "RNC", mainData);

                          });
                          $http.get(kpiurl4a + from6Week_Ly + toWeek_Ly)          //6
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC6", "RNC", mainData);

                          });
                          $http.get(kpiurl4a + from13Week + toWeek)          //7
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC7", "RNC", mainData);

                          });
                            $http.get(kpiurl4a + from13Week_Ly + toWeek_Ly)   //8
                              .success(function(response)   
                               {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4a(returnedData);

                              $.barChart("#kpi4AbarC8", "RNC", mainData);

                          });


                      var kpiurl4b = services.common1 + services.kpi4b;  // forthB KPI
          

                       $http.get(kpiurl4b + fromWeek + toWeek)         //1       
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC1", "REC", mainData);
                       });
                        $http.get(kpiurl4b + fromWeek_Ly + toWeek_Ly)   //2            
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC2", "REC", mainData);
                       });

                             $http.get(kpiurl4b + from1Week + toLWeek)                  // 3
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC3", "RNC", mainData);

                            });
                        $http.get(kpiurl4b + from1Week_Ly + toLWeek_Ly)         //4
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC4", "RNC", mainData);

                          });
                        $http.get(kpiurl4b + from6Week + toWeek)        //5
                          .success(function(response)   
                              {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC5", "RNC", mainData);

                          });
                          $http.get(kpiurl4b + from6Week_Ly + toWeek_Ly)          //6
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC6", "RNC", mainData);

                          });
                          $http.get(kpiurl4b + from13Week + toWeek)          //7
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC7", "RNC", mainData);

                          });
                            $http.get(kpiurl4b + from13Week_Ly + toWeek_Ly)   //8
                              .success(function(response)   
                               {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI4b(returnedData);

                              $.barChart("#kpi4BbarC8", "RNC", mainData);

                          });


                        var kpiurl5 = services.common1 + services.kpi5;  // fifth KPI
          

                       $http.get(kpiurl5 + fromWeek + toWeek)         //1       
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC1", "SCR", mainData);
                       });
                        $http.get(kpiurl5 + fromWeek_Ly + toWeek_Ly)   //2            
                        .success(function(response) 
                             {  
                              var header=  $.formatToJSON(response);
                             // console.log(JSON.stringify(header));
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC2", "SCR", mainData);
                       });
                        $http.get(kpiurl5 + from1Week + toLWeek)                  // 3
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC3", "APPV", mainData);

                            });
                        $http.get(kpiurl5 + from1Week_Ly + toLWeek_Ly)         //4
                        .success(function(response)   
                            {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC4", "APPV", mainData);

                          });
                        $http.get(kpiurl5 + from6Week + toWeek)        //5
                          .success(function(response)   
                              {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC5", "APPV", mainData);

                          });
                          $http.get(kpiurl5 + from6Week_Ly + toWeek_Ly)          //6
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC6", "APPV", mainData);

                          });
                          $http.get(kpiurl5 + from13Week + toWeek)          //7
                            .success(function(response)   
                                {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC7", "APPV", mainData);

                          });
                            $http.get(kpiurl5 + from13Week_Ly + toWeek_Ly)   //8
                              .success(function(response)   
                               {
                              var header=  $.formatToJSON(response);
                              var filteredCountries = $.filteredCountry(header);
                             
                              var returnedData = $.filtered(filteredCountries);

                              var mainData = $.getDataforKPI5(returnedData);

                              $.barChart("#kpi5barC8", "APPV", mainData);

                          });




        };


          


        $scope.filterall();

       
      

          
                   
});